package com.example.healthyfoodcare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);
    }
    public void register(View v)
    {
        Intent t=new Intent(register.this,login.class);
        //Toast.makeText(v.getContext(), "successfully registered,Login Now!", Toast.LENGTH_SHORT).show();
        startActivity(t);
    }
}
