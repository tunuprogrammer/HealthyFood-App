package com.example.healthyfoodcare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);
    }
    public void login(View v)
    {
        Intent i=new Intent(login.this,Dashboard_page.class);
        //Toast.makeText(v.getContext(), "successfully login", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }
    public void register(View v)
    {
        Intent r=new Intent(login.this,register.class);
        startActivity(r);
    }
}
